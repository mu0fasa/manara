/* صفحتا «كل المقالات» و«عرض مقال» من البيانات المحلية (بدون سيرفر) */
(function () {
  const data = window.ARTICLES || [];

  /* ---------- قائمة المقالات + بحث ---------- */
  const list = document.getElementById("list");
  if (list) {
    const search = document.getElementById("search");
    const category = document.getElementById("category");
    [...new Set(data.map((a) => a.category))].forEach((c) =>
      category.appendChild(el("option", { value: c, text: c }))
    );

    const render = () => {
      const q = search.value.trim().toLowerCase();
      const cat = category.value;
      const rows = data.filter(
        (a) =>
          (!cat || a.category === cat) &&
          (!q || [a.title, a.summary, a.body].some((t) => t.toLowerCase().includes(q)))
      );
      list.replaceChildren(
        ...(rows.length
          ? rows.map((a) =>
              el("article", {},
                el("div", { class: "article-header" },
                  el("h3", {}, el("a", { href: "article.html#" + a.slug, text: a.title })),
                  el("p", { class: "article-meta" },
                    el("span", { class: "badge", text: a.category }),
                    ` ${a.date} | ${a.author}`)
                ),
                el("p", { text: a.summary }),
                el("p", {}, el("a", { class: "btn", href: "article.html#" + a.slug, text: "قراءة المقال ←" }))
              )
            )
          : [el("p", { class: "muted", text: "لا توجد مقالات مطابقة." })])
      );
    };
    search.addEventListener("input", render);
    category.addEventListener("change", render);
    render();
  }

  /* ---------- عرض مقال واحد ---------- */
  const box = document.getElementById("article");
  if (box) {
    const show = () => {
      const slug = decodeURIComponent(location.hash.slice(1));
      const a = data.find((x) => x.slug === slug);
      if (!a) {
        box.replaceChildren(el("p", { class: "alert error", text: "المقال غير موجود." }));
        return;
      }
      document.title = a.title + " | منصة منارة التعليمية";
      box.replaceChildren(
        el("header", { class: "article-header" },
          el("h1", { text: a.title }),
          el("p", { class: "article-meta" },
            el("span", { class: "badge", text: a.category }),
            ` ${a.date} | ${a.author}`)
        ),
        ...a.body.split(/\n{2,}/).filter(Boolean).map((p) => el("p", { text: p }))
      );
    };
    window.addEventListener("hashchange", show);
    show();
  }
})();
