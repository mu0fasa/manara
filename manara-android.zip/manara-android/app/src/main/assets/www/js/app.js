/* =====================================================
   منصة منارة (نسخة بدون إنترنت) — الدوال المشتركة
   ===================================================== */
const MANARA_CONFIG = {
  email: "info@manara-edu.example",   // ← ضع إيميلك الحقيقي هنا
  phoneCountry: "SD",                 // رمز الدولة الافتراضي
  phoneNumber: "",                    // اختياري: رقم المنصة (بدون رمز الدولة)
};

const BASE = document.body.dataset.base || "";

/* ---------- عناصر DOM بشكل آمن ---------- */
function el(tag, attrs, ...children) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const c of children.flat()) n.append(c);
  return n;
}

/* ---------- رسالة صغيرة ---------- */
function toast(msg) {
  let t = document.getElementById("toast");
  if (!t) {
    t = el("div", { id: "toast", role: "status" });
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

/* ---------- النسخ إلى الحافظة ---------- */
async function copyText(text, okMsg) {
  let done = false;
  try {
    await navigator.clipboard.writeText(text);
    done = true;
  } catch {}
  if (!done) {
    const ta = el("textarea", { style: "position:fixed;opacity:0;top:0" });
    ta.value = text;
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { done = document.execCommand("copy"); } catch {}
    ta.remove();
  }
  toast(done ? okMsg || "تم النسخ ✔" : "تعذر النسخ");
}

/* ---------- شريط التنقل: إضافة «كل المقالات» ---------- */
function initNav() {
  const nav = document.querySelector("nav");
  if (!nav || nav.querySelector('a[href$="articles.html"]')) return;
  const a = el("a", { href: BASE + "articles.html", text: "كل المقالات" });
  if (/articles\.html$|article\.html$/.test(location.pathname)) a.classList.add("active");
  const contact = nav.querySelector('a[href$="contact.html"]');
  nav.insertBefore(a, contact);
}

/* ---------- الفيديو يحتاج إنترنت: رسالة بديلة عند عدم الاتصال ---------- */
function initOfflineVideo() {
  document.querySelectorAll(".media-container").forEach((box) => {
    const note = el("p", {
      class: "alert error",
      text: "هذا الفيديو يحتاج اتصالاً بالإنترنت. باقي محتوى التطبيق يعمل بدونه.",
    });
    note.hidden = navigator.onLine;
    box.after(note);
    const sync = () => {
      note.hidden = navigator.onLine;
    };
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
  });
}

/* ---------- صفحة اتصل بنا ---------- */
function initContact() {
  const emailEl = document.getElementById("emailText");
  if (!emailEl) return;

  emailEl.textContent = MANARA_CONFIG.email;
  document.getElementById("emailLink").href = "mailto:" + MANARA_CONFIG.email;
  document.getElementById("copyEmail").addEventListener("click", () =>
    copyText(MANARA_CONFIG.email, "تم نسخ الإيميل ✔")
  );

  const sel = document.getElementById("countryCode");
  (window.COUNTRIES || []).forEach(([name, iso, dial, flag]) => {
    const o = el("option", { value: dial, text: `${flag} ${dial} ${name}` });
    if (iso === MANARA_CONFIG.phoneCountry) o.selected = true;
    sel.appendChild(o);
  });
  const phone = document.getElementById("phone");

  document.getElementById("copyPhone").addEventListener("click", () => {
    const digits = phone.value.replace(/\D/g, "").replace(/^0+/, "");
    if (!digits) return toast("اكتب رقم الهاتف أولاً");
    copyText(sel.value + digits, "تم نسخ الرقم مع الكود ✔");
  });

  const pubRow = document.getElementById("publicPhoneRow");
  if (MANARA_CONFIG.phoneNumber) {
    const dial = (window.COUNTRIES.find((c) => c[1] === MANARA_CONFIG.phoneCountry) || [])[2] || "";
    const full = dial + MANARA_CONFIG.phoneNumber;
    document.getElementById("publicPhone").textContent = full;
    document.getElementById("copyPublicPhone").addEventListener("click", () =>
      copyText(full, "تم نسخ رقم المنصة ✔")
    );
  } else if (pubRow) pubRow.remove();

  // الإرسال عبر تطبيق البريد في الهاتف (يعمل متى توفر الإنترنت)
  document.getElementById("contactForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const mail = document.getElementById("fromEmail").value.trim();
    const msg = document.getElementById("message").value.trim();
    const digits = phone.value.replace(/\D/g, "").replace(/^0+/, "");
    const body =
      `الاسم: ${name}\nالإيميل: ${mail}\n` +
      (digits ? `الهاتف: ${sel.value}${digits}\n` : "") +
      `\n${msg}`;
    window.location.href =
      `mailto:${MANARA_CONFIG.email}?subject=${encodeURIComponent("رسالة من تطبيق منارة")}` +
      `&body=${encodeURIComponent(body)}`;
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initOfflineVideo();
  initContact();
});
