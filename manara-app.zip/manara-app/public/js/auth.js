/* تسجيل الدخول وإنشاء الحساب */
(function () {
  const box = document.getElementById("formAlert");

  // وجهة ما بعد الدخول: مسار داخلي فقط
  function nextUrl() {
    const n = new URLSearchParams(location.search).get("next");
    return n && /^\/[A-Za-z0-9_\-./]*(\?[^\\\s]*)?$/.test(n) && !n.startsWith("//") ? n : "/index.html";
  }

  async function submit(form, path, body) {
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    try {
      await api(path, { method: "POST", body });
      location.href = nextUrl();
    } catch (err) {
      showAlert(box, err.message);
      btn.disabled = false;
    }
  }

  const login = document.getElementById("loginForm");
  if (login) {
    login.addEventListener("submit", (e) => {
      e.preventDefault();
      submit(login, "/login", {
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
      });
    });
  }

  const reg = document.getElementById("registerForm");
  if (reg) {
    const sel = document.getElementById("countryCode");
    fillCountrySelect(sel);
    reg.addEventListener("submit", (e) => {
      e.preventDefault();
      submit(reg, "/register", {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        countryCode: sel.value,
        phone: document.getElementById("phone").value,
        password: document.getElementById("password").value,
      });
    });
  }
})();
