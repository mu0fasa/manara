/* صفحة كل المقالات: بحث + تصنيف */
(function () {
  const list = document.getElementById("list");
  const search = document.getElementById("search");
  const category = document.getElementById("category");
  let timer;
  let loadedCategories = false;

  function card(a) {
    return el(
      "article",
      {},
      el("div", { class: "article-header" },
        el("h3", {}, el("a", { href: "article.html?s=" + encodeURIComponent(a.slug), text: a.title })),
        el("p", { class: "article-meta" },
          el("span", { class: "badge", text: a.category }),
          ` ${a.created_at.slice(0, 10)} | ${a.author}`)
      ),
      el("p", { text: a.summary }),
      el("p", {}, el("a", { class: "btn", href: "article.html?s=" + encodeURIComponent(a.slug), text: "قراءة المقال ←" }))
    );
  }

  async function load() {
    const params = new URLSearchParams();
    if (search.value.trim()) params.set("q", search.value.trim());
    if (category.value) params.set("category", category.value);
    try {
      const d = await api("/articles?" + params);
      if (!loadedCategories) {
        d.categories.forEach((c) => category.appendChild(el("option", { value: c, text: c })));
        loadedCategories = true;
      }
      list.replaceChildren(
        ...(d.articles.length ? d.articles.map(card) : [el("p", { class: "muted", text: "لا توجد مقالات مطابقة." })])
      );
    } catch (err) {
      list.replaceChildren(el("p", { class: "alert error", text: err.message }));
    }
  }

  search.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(load, 250);
  });
  category.addEventListener("change", load);
  load();
})();
