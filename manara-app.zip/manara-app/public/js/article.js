/* عرض مقال واحد من قاعدة البيانات */
(async function () {
  const box = document.getElementById("article");
  const slug = new URLSearchParams(location.search).get("s");
  if (!slug) {
    box.replaceChildren(el("p", { class: "alert error", text: "لم يتم تحديد المقال." }));
    return;
  }
  try {
    const { article: a } = await api("/articles/" + encodeURIComponent(slug));
    document.title = a.title + " | منصة منارة التعليمية";
    box.replaceChildren(
      el("header", { class: "article-header" },
        el("h1", { text: a.title }),
        el("p", { class: "article-meta" },
          el("span", { class: "badge", text: a.category }),
          ` ${a.created_at.slice(0, 10)} | ${a.author}`)
      ),
      // نص المقال يُعرض كنص عادي (بدون HTML) لمنع XSS
      ...a.body.split(/\n{2,}/).filter(Boolean).map((p) => el("p", { text: p })),
      el("div", { class: "article-actions" },
        el("button", {
          type: "button",
          class: "btn btn-secondary",
          text: "نسخ رابط المقال",
          onclick: () => copyText(location.href, "تم نسخ الرابط ✔"),
        }))
    );
  } catch (err) {
    box.replaceChildren(el("p", { class: "alert error", text: err.message }));
  }
})();
