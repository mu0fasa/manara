/* =====================================================
   منصة منارة — الدوال المشتركة بين كل الصفحات
   ===================================================== */
const BASE = document.body.dataset.base || "";

/* ---------- طلبات الـ API ---------- */
async function api(path, opts = {}) {
  const o = { credentials: "same-origin", headers: {}, ...opts };
  if (o.body && typeof o.body !== "string") {
    o.body = JSON.stringify(o.body);
    o.headers["Content-Type"] = "application/json";
  }
  let r;
  try {
    r = await fetch("/api" + path, o);
  } catch {
    throw new Error("تعذر الاتصال بالسيرفر");
  }
  let data = null;
  try { data = await r.json(); } catch {}
  if (!r.ok) throw new Error((data && data.error) || "حدث خطأ، حاول مرة أخرى");
  return data;
}

/* ---------- عناصر DOM بشكل آمن (بدون innerHTML) ---------- */
function el(tag, attrs, ...children) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const c of children.flat()) n.append(c);
  return n;
}

/* ---------- رسالة صغيرة ---------- */
function toast(msg) {
  let t = document.getElementById("toast");
  if (!t) {
    t = el("div", { id: "toast", role: "status" });
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

/* ---------- النسخ إلى الحافظة ---------- */
async function copyText(text, okMsg) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = el("textarea", { style: "position:fixed;opacity:0" });
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  toast(okMsg || "تم النسخ ✔");
}

/* ---------- قائمة أكواد الدول ---------- */
function fillCountrySelect(sel, defaultIso = "SD") {
  (window.COUNTRIES || []).forEach(([name, iso, dial, flag]) => {
    const o = el("option", { value: dial, text: `${flag} ${dial} ${name}` });
    if (iso === defaultIso) o.selected = true;
    sel.appendChild(o);
  });
}

/* ---------- رسالة نجاح/خطأ داخل النماذج ---------- */
function showAlert(box, msg, type = "error") {
  box.className = "alert " + type;
  box.textContent = msg;
  box.hidden = false;
}

/* ---------- المستخدم الحالي وشريط التنقل ---------- */
let currentUser = null;
const userReady = api("/me").then((d) => (currentUser = d.user)).catch(() => null);

async function initNav() {
  const nav = document.querySelector("nav");
  if (!nav) return;
  const here = location.pathname.split("/").pop() || "index.html";

  const add = (href, text, extra = {}) => {
    const a = el("a", { href: BASE + href, text, ...extra });
    if (href === here) a.classList.add("active");
    nav.appendChild(a);
    return a;
  };

  if (!nav.querySelector('a[href$="articles.html"]')) add("articles.html", "كل المقالات");
  const user = await userReady;
  if (user) {
    if (user.role === "admin") add("admin.html", "لوحة الإدارة");
    nav.appendChild(el("span", { class: "nav-user", text: "👤 " + user.name }));
    nav.appendChild(
      el("a", {
        href: "#",
        text: "خروج",
        onclick: async (e) => {
          e.preventDefault();
          try { await api("/logout", { method: "POST" }); } catch {}
          location.href = BASE + "index.html";
        },
      })
    );
  } else {
    add("login.html", "دخول");
    add("register.html", "حساب جديد", { class: "nav-cta" });
  }
}

/* ---------- صفحة اتصل بنا ---------- */
async function initContact() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  const sel = document.getElementById("countryCode");
  fillCountrySelect(sel);
  const phone = document.getElementById("phone");
  const alertBox = document.getElementById("formAlert");

  try {
    const cfg = await api("/config");
    document.getElementById("emailText").textContent = cfg.contactEmail;
    document.getElementById("emailLink").href = "mailto:" + cfg.contactEmail;
    document.getElementById("copyEmail").addEventListener("click", () =>
      copyText(cfg.contactEmail, "تم نسخ الإيميل ✔")
    );
    const row = document.getElementById("publicPhoneRow");
    if (cfg.contactPhone) {
      document.getElementById("publicPhone").textContent = cfg.contactPhone;
      document.getElementById("copyPublicPhone").addEventListener("click", () =>
        copyText(cfg.contactPhone, "تم نسخ رقم المنصة ✔")
      );
    } else if (row) row.remove();
  } catch {
    document.getElementById("emailText").textContent = "تعذر تحميل الإيميل";
  }

  const user = await userReady;
  if (user) {
    document.getElementById("name").value = user.name;
    document.getElementById("fromEmail").value = user.email;
    if (user.countryCode) sel.value = user.countryCode;
    if (user.phone) phone.value = user.phone;
  }

  document.getElementById("copyPhone").addEventListener("click", () => {
    const digits = phone.value.replace(/\D/g, "").replace(/^0+/, "");
    if (!digits) return toast("اكتب رقم الهاتف أولاً");
    copyText(sel.value + digits, "تم نسخ الرقم مع الكود ✔");
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    try {
      await api("/contact", {
        method: "POST",
        body: {
          name: document.getElementById("name").value,
          email: document.getElementById("fromEmail").value,
          countryCode: sel.value,
          phone: phone.value,
          message: document.getElementById("message").value,
        },
      });
      document.getElementById("message").value = "";
      showAlert(alertBox, "تم إرسال رسالتك بنجاح، سنرد عليك قريباً ✔", "success");
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      btn.disabled = false;
    }
  });
}

/* ---------- تثبيت التطبيق (PWA) ---------- */
let deferredPrompt = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const b = document.getElementById("installBtn");
  if (b) b.style.display = "inline-block";
});
function initInstall() {
  const b = document.getElementById("installBtn");
  if (!b) return;
  b.addEventListener("click", async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    b.style.display = "none";
  });
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").catch(() => {});
}

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initContact();
  initInstall();
});
