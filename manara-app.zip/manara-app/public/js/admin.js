/* لوحة الإدارة: مقالات + رسائل + مستخدمون */
(async function () {
  const gate = document.getElementById("gate");
  const panel = document.getElementById("panel");
  const user = await userReady;

  if (!user) {
    location.href = "/login.html?next=/admin.html";
    return;
  }
  if (user.role !== "admin") {
    showAlert(gate, "هذه الصفحة للمشرفين فقط.");
    return;
  }
  panel.hidden = false;

  const phoneText = (x) => (x.phone ? `${x.country_code || ""}${x.phone}` : "—");

  /* ---- المقالات ---- */
  async function loadArticles() {
    const box = document.getElementById("articlesList");
    const { articles } = await api("/articles");
    box.replaceChildren(
      ...(articles.length
        ? articles.map((a) =>
            el("div", { class: "admin-item" },
              el("div", {},
                el("strong", {}, el("a", { href: "article.html?s=" + encodeURIComponent(a.slug), text: a.title })),
                el("div", { class: "meta", text: `${a.category} • ${a.created_at.slice(0, 10)}` })
              ),
              el("button", {
                type: "button",
                class: "btn btn-danger",
                text: "حذف",
                onclick: async () => {
                  if (!confirm("حذف المقال نهائياً؟")) return;
                  try {
                    await api("/articles/" + a.id, { method: "DELETE" });
                    toast("تم الحذف ✔");
                    loadArticles();
                  } catch (e) { toast(e.message); }
                },
              })
            )
          )
        : [el("p", { class: "muted", text: "لا توجد مقالات." })])
    );
  }

  /* ---- الرسائل ---- */
  async function loadMessages() {
    const box = document.getElementById("messagesList");
    const { messages } = await api("/messages");
    box.replaceChildren(
      ...(messages.length
        ? messages.map((m) =>
            el("div", { class: "admin-item" },
              el("div", { style: "flex:1" },
                el("strong", { text: m.name }),
                el("div", { class: "meta", dir: "ltr", text: `${m.email} • ${phoneText(m)} • ${m.created_at}` }),
                el("p", { text: m.message })
              ),
              el("button", {
                type: "button",
                class: "btn btn-secondary",
                text: "نسخ الإيميل",
                onclick: () => copyText(m.email, "تم نسخ الإيميل ✔"),
              })
            )
          )
        : [el("p", { class: "muted", text: "لا توجد رسائل بعد." })])
    );
  }

  /* ---- المستخدمون ---- */
  async function loadUsers() {
    const box = document.getElementById("usersList");
    const { users } = await api("/users");
    box.replaceChildren(
      el("div", { class: "table-wrap" },
        el("table", {},
          el("thead", {}, el("tr", {}, ...["الاسم", "الإيميل", "الهاتف", "الدور", "التسجيل"].map((h) => el("th", { text: h })))),
          el("tbody", {}, ...users.map((u) =>
            el("tr", {},
              el("td", { text: u.name }),
              el("td", { dir: "ltr", text: u.email }),
              el("td", { dir: "ltr", text: phoneText(u) }),
              el("td", { text: u.role === "admin" ? "مشرف" : "طالب" }),
              el("td", { text: u.created_at.slice(0, 10) })
            )
          ))
        )
      )
    );
  }

  /* ---- نموذج إضافة مقال ---- */
  const form = document.getElementById("articleForm");
  const alertBox = document.getElementById("formAlert");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    try {
      await api("/articles", {
        method: "POST",
        body: {
          title: document.getElementById("title").value,
          category: document.getElementById("category").value,
          summary: document.getElementById("summary").value,
          body: document.getElementById("body").value,
        },
      });
      form.reset();
      showAlert(alertBox, "تم نشر المقال ✔", "success");
      loadArticles();
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      btn.disabled = false;
    }
  });

  try {
    await Promise.all([loadArticles(), loadMessages(), loadUsers()]);
  } catch (e) {
    showAlert(gate, e.message);
  }
})();
