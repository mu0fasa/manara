"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const os = require("node:os");
const fs = require("node:fs");
const path = require("node:path");
const { createApp } = require("../server.js");

let app, base, dir;
const jar = {}; // كوكيز لكل مستخدم تجريبي

before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "manara-test-"));
  app = createApp({ dataDir: dir, dbFile: ":memory:", rateLimit: false, contactEmail: "test@example.com" });
  await new Promise((r) => app.server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${app.server.address().port}`;
});

after(async () => {
  await new Promise((r) => app.server.close(r));
  fs.rmSync(dir, { recursive: true, force: true });
});

async function call(method, url, body, who) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (who && jar[who]) headers.Cookie = jar[who];
  const r = await fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const sc = r.headers.get("set-cookie");
  if (who && sc && /manara_session=[^;]+/.test(sc)) jar[who] = sc.split(";")[0];
  let data = null;
  try {
    data = await r.json();
  } catch {}
  return { status: r.status, data, headers: r.headers };
}

test("الأول يسجل فيصبح مشرفاً، والثاني طالب", async () => {
  const a = await call("POST", "/api/register", {
    name: "أحمد", email: "Admin@Example.com", password: "password123", countryCode: "+249", phone: "0912345678",
  }, "admin");
  assert.equal(a.status, 201);
  assert.equal(a.data.user.role, "admin");
  assert.equal(a.data.user.email, "admin@example.com");
  assert.equal(a.data.user.phone, "912345678");

  const s = await call("POST", "/api/register", { name: "سمر", email: "s@example.com", password: "password123" }, "student");
  assert.equal(s.status, 201);
  assert.equal(s.data.user.role, "student");
});

test("رفض الإيميل المكرر وكلمة المرور القصيرة وكود الدولة الخاطئ", async () => {
  const dup = await call("POST", "/api/register", { name: "x y", email: "s@example.com", password: "password123" });
  assert.equal(dup.status, 409);
  const short = await call("POST", "/api/register", { name: "x y", email: "n@example.com", password: "123" });
  assert.equal(short.status, 400);
  const badCode = await call("POST", "/api/register", {
    name: "x y", email: "n@example.com", password: "password123", countryCode: "+999", phone: "912345678",
  });
  assert.equal(badCode.status, 400);
});

test("تسجيل الدخول والخروج و /api/me", async () => {
  const bad = await call("POST", "/api/login", { email: "s@example.com", password: "wrong-pass" });
  assert.equal(bad.status, 401);
  const none = await call("POST", "/api/login", { email: "nobody@example.com", password: "whatever123" });
  assert.equal(none.status, 401);

  const ok = await call("POST", "/api/login", { email: "s@example.com", password: "password123" }, "student2");
  assert.equal(ok.status, 200);
  const me = await call("GET", "/api/me", undefined, "student2");
  assert.equal(me.data.user.email, "s@example.com");
  const anon = await call("GET", "/api/me");
  assert.equal(anon.data.user, null);
});

test("الجلسة المعدَّلة أو المزورة مرفوضة", async () => {
  const fake = jar.admin.replace(/\.[^.]+$/, ".AAAA");
  const r = await fetch(base + "/api/me", { headers: { Cookie: fake } });
  assert.equal((await r.json()).user, null);
});

test("المقالات: القائمة والبحث والعرض", async () => {
  const list = await call("GET", "/api/articles");
  assert.equal(list.status, 200);
  assert.ok(list.data.articles.length >= 2);
  assert.ok(list.data.categories.includes("الذكاء الاصطناعي"));

  const search = await call("GET", "/api/articles?q=" + encodeURIComponent("الذكاء"));
  assert.ok(search.data.articles.length >= 1);
  const none = await call("GET", "/api/articles?q=" + encodeURIComponent("100%_غير_موجود"));
  assert.equal(none.data.articles.length, 0);

  const one = await call("GET", "/api/articles/web-basics");
  assert.equal(one.status, 200);
  assert.ok(one.data.article.body.length > 20);
  assert.equal((await call("GET", "/api/articles/nope")).status, 404);
});

test("إضافة وحذف المقالات للمشرف فقط", async () => {
  const payload = { title: "مقال تجريبي جديد", category: "تجارب", summary: "ملخص المقال التجريبي", body: "نص المقال التجريبي الطويل بما يكفي." };
  assert.equal((await call("POST", "/api/articles", payload)).status, 401);
  assert.equal((await call("POST", "/api/articles", payload, "student")).status, 403);

  const c = await call("POST", "/api/articles", payload, "admin");
  assert.equal(c.status, 201);
  const again = await call("POST", "/api/articles", payload, "admin"); // نفس العنوان => slug مختلف
  assert.equal(again.status, 201);
  assert.notEqual(c.data.article.slug, again.data.article.slug);

  assert.equal((await call("DELETE", `/api/articles/${c.data.article.id}`, undefined, "student")).status, 403);
  assert.equal((await call("DELETE", `/api/articles/${c.data.article.id}`, undefined, "admin")).status, 200);
  assert.equal((await call("DELETE", `/api/articles/${c.data.article.id}`, undefined, "admin")).status, 404);
});

test("رسائل التواصل تُحفظ ويقرؤها المشرف فقط", async () => {
  const bad = await call("POST", "/api/contact", { name: "زائر", email: "bad", message: "مرحبا بكم" });
  assert.equal(bad.status, 400);
  const ok = await call("POST", "/api/contact", {
    name: "زائر", email: "v@example.com", message: "مرحباً، لدي سؤال", countryCode: "+20", phone: "1001234567",
  });
  assert.equal(ok.status, 201);
  assert.equal((await call("GET", "/api/messages", undefined, "student")).status, 403);
  const list = await call("GET", "/api/messages", undefined, "admin");
  assert.equal(list.data.messages.length, 1);
  assert.equal(list.data.messages[0].country_code, "+20");
});

test("الإعدادات العامة والتحقق من نوع المحتوى وCSRF", async () => {
  assert.equal((await call("GET", "/api/config")).data.contactEmail, "test@example.com");
  const r = await fetch(base + "/api/contact", { method: "POST", body: "x=1", headers: { "Content-Type": "text/plain" } });
  assert.equal(r.status, 415);
  const csrf = await fetch(base + "/api/logout", { method: "POST", headers: { Origin: "https://evil.example" } });
  assert.equal(csrf.status, 403);
});

test("الملفات الثابتة وحماية المسارات", async () => {
  const home = await fetch(base + "/");
  assert.equal(home.status, 200);
  assert.match(home.headers.get("content-type"), /text\/html/);
  assert.ok(home.headers.get("content-security-policy"));
  assert.equal((await fetch(base + "/../server.js")).status, 404);
  assert.equal((await fetch(base + "/%2e%2e/server.js")).status, 404);
  assert.equal((await fetch(base + "/data/manara.db")).status, 404);
  assert.equal((await fetch(base + "/nope.html")).status, 404);
});
