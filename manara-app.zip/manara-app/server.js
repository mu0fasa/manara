"use strict";
/**
 * منصة منارة التعليمية — سيرفر Node.js + SQLite
 * بدون أي مكتبات خارجية (يستخدم node:sqlite و crypto المدمجة).
 */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { promisify } = require("node:util");
const { DatabaseSync } = require("node:sqlite");
const COUNTRIES = require("./public/js/countries.js");

const scrypt = promisify(crypto.scrypt);
const DIAL_CODES = new Set(COUNTRIES.map((c) => c[2]));
const COOKIE = "manara_session";
const SESSION_DAYS = 7;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json",
};

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

/* ============================ المقالات الافتراضية ============================ */
const SEED_ARTICLES = [
  {
    slug: "web-basics",
    title: "أساسيات تصميم وتطوير الويب للمبتدئين باستخدام HTML5 و CSS3",
    category: "برمجيات الويب",
    summary: "تعرّف على الوسوم الدلالية في HTML5 وكيف تبني صفحة ويب منظمة وسهلة القراءة لمحركات البحث.",
    body: [
      "تعتمد جميع المواقع الإلكترونية الحديثة على لغتي HTML و CSS. الأولى تبني هيكل الصفحة، والثانية تتحكم في شكلها وألوانها وتخطيطها.",
      "الوسوم الدلالية مثل header وnav وmain وsection وarticle وfooter توضح معنى كل جزء من الصفحة للمتصفح وللمطور ولمحركات البحث، وتجعل الكود أسهل في القراءة والصيانة.",
      "نصيحة من منارة: احرص دائماً على كتابة كود نظيف وتسمية العناصر بدقة، فهذا يسرّع الأداء ويسهّل العمل الجماعي.",
      "البرمجة ليست مجرد كتابة شفرات، بل هي فن حل المشكلات وتحويل الأفكار إلى واقع ملموس.",
    ].join("\n\n"),
    author: "فريق المجموعة الرابعة",
  },
  {
    slug: "ai-in-education",
    title: "مقدمة في الذكاء الاصطناعي وتطبيقاته في التعليم الرقمي",
    category: "الذكاء الاصطناعي",
    summary: "كيف تساهم أدوات الذكاء الاصطناعي في التعلم الشخصي والمساعدة البرمجية وتحليل النصوص، وما حدود استخدامها الأخلاقي.",
    body: [
      "الذكاء الاصطناعي هو قدرة الأنظمة والآلات على محاكاة بعض القدرات الذهنية البشرية واستنتاج الأنماط من البيانات الضخمة.",
      "من أهم استخداماته في التعليم: التعلم الشخصي التكيفي الذي يوفر مسارات تناسب قدرة كل طالب، والمساعدات البرمجية ومراجعة الكود، وتحليل النصوص والترجمة والأبحاث الأكاديمية.",
      "ورغم فوائده، يجب الالتزام بالأخلاقيات الأكاديمية وعدم الاعتماد الكلي على الآلة دون تفكير نقدي بشري.",
      "الذكاء الاصطناعي لن يستبدل الإنسان، لكن الإنسان الذي يتقن استخدامه سيكون الأقدر على النجاح في المستقبل.",
    ].join("\n\n"),
    author: "فريق المجموعة الرابعة",
  },
];

/* ============================ أدوات مساعدة ============================ */
const b64u = (v) => Buffer.from(v).toString("base64url");

function str(v, min, max, label) {
  if (typeof v !== "string") throw new HttpError(400, `${label} مطلوب`);
  const s = v.trim();
  if (s.length < min) throw new HttpError(400, `${label} قصير جداً`);
  if (s.length > max) throw new HttpError(400, `${label} طويل جداً`);
  return s;
}

function validEmail(v) {
  const e = str(v, 5, 254, "الإيميل").toLowerCase();
  if (!/^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(e)) throw new HttpError(400, "صيغة الإيميل غير صحيحة");
  return e;
}

/** يرجع { country_code, phone } أو {null,null} إذا لم يُرسل رقم */
function validPhone(countryCode, phone) {
  const raw = typeof phone === "string" ? phone.replace(/\D/g, "").replace(/^0+/, "") : "";
  if (!raw) return { country_code: null, phone: null };
  if (!DIAL_CODES.has(countryCode)) throw new HttpError(400, "كود الدولة غير صحيح");
  if (raw.length < 6 || raw.length > 12) throw new HttpError(400, "رقم الهاتف غير صحيح");
  return { country_code: countryCode, phone: raw };
}

function slugify(title) {
  const base = title
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return base || "article";
}

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = await scrypt(pw, salt, 64);
  return `scrypt$${salt.toString("hex")}$${h.toString("hex")}`;
}

async function checkPassword(pw, stored) {
  const [alg, s, h] = String(stored).split("$");
  if (alg !== "scrypt" || !s || !h) return false;
  const expected = Buffer.from(h, "hex");
  const got = await scrypt(pw, Buffer.from(s, "hex"), expected.length);
  return crypto.timingSafeEqual(got, expected);
}

function parseCookies(header) {
  const out = {};
  for (const part of String(header || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

/* ============================ إنشاء التطبيق ============================ */
function createApp(opts = {}) {
  const dataDir = opts.dataDir || process.env.DATA_DIR || path.join(__dirname, "data");
  const publicDir = path.join(__dirname, "public");
  const contactEmail = opts.contactEmail || process.env.CONTACT_EMAIL || "info@manara-edu.example";
  const contactPhone = opts.contactPhone || process.env.CONTACT_PHONE || "";
  const adminEmail = (opts.adminEmail || process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const trustProxy = opts.trustProxy ?? process.env.TRUST_PROXY === "1";
  const limitsOn = opts.rateLimit !== false;

  fs.mkdirSync(dataDir, { recursive: true });

  /* ---- السر الخاص بتوقيع الجلسات ---- */
  let secret = opts.secret || process.env.SESSION_SECRET;
  if (!secret) {
    const f = path.join(dataDir, "secret.key");
    try {
      secret = fs.readFileSync(f, "utf8");
    } catch {
      secret = crypto.randomBytes(32).toString("hex");
      fs.writeFileSync(f, secret, { mode: 0o600 });
    }
  }

  /* ---- قاعدة البيانات ---- */
  const db = new DatabaseSync(opts.dbFile || path.join(dataDir, "manara.db"));
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      country_code TEXT,
      phone TEXT,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS articles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      summary TEXT NOT NULL,
      body TEXT NOT NULL,
      author TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      country_code TEXT,
      phone TEXT,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  if (db.prepare("SELECT COUNT(*) AS n FROM articles").get().n === 0) {
    const ins = db.prepare(
      "INSERT INTO articles (slug,title,category,summary,body,author) VALUES (?,?,?,?,?,?)"
    );
    for (const a of SEED_ARTICLES) ins.run(a.slug, a.title, a.category, a.summary, a.body, a.author);
  }

  const q = {
    userByEmail: db.prepare("SELECT * FROM users WHERE email = ?"),
    userById: db.prepare("SELECT id,name,email,country_code,phone,role FROM users WHERE id = ?"),
    userCount: db.prepare("SELECT COUNT(*) AS n FROM users"),
    insertUser: db.prepare(
      "INSERT INTO users (name,email,country_code,phone,password_hash,role) VALUES (?,?,?,?,?,?)"
    ),
    articleBySlug: db.prepare("SELECT * FROM articles WHERE slug = ?"),
    insertArticle: db.prepare(
      "INSERT INTO articles (slug,title,category,summary,body,author) VALUES (?,?,?,?,?,?)"
    ),
    deleteArticle: db.prepare("DELETE FROM articles WHERE id = ?"),
    categories: db.prepare("SELECT DISTINCT category FROM articles ORDER BY category"),
    insertMessage: db.prepare(
      "INSERT INTO messages (name,email,country_code,phone,message) VALUES (?,?,?,?,?)"
    ),
    messages: db.prepare("SELECT * FROM messages ORDER BY id DESC LIMIT 200"),
    users: db.prepare(
      "SELECT id,name,email,country_code,phone,role,created_at FROM users ORDER BY id DESC LIMIT 500"
    ),
  };

  /* ---- الجلسات (رمز موقّع) ---- */
  const hmac = (body) => crypto.createHmac("sha256", secret).update(body).digest("base64url");
  function signToken(payload) {
    const body = b64u(JSON.stringify(payload));
    return `${body}.${hmac(body)}`;
  }
  function verifyToken(tok) {
    if (typeof tok !== "string") return null;
    const [body, sig] = tok.split(".");
    if (!body || !sig) return null;
    const a = Buffer.from(sig);
    const b = Buffer.from(hmac(body));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    try {
      const p = JSON.parse(Buffer.from(body, "base64url").toString());
      return p.exp > Date.now() / 1000 ? p : null;
    } catch {
      return null;
    }
  }
  function currentUser(req) {
    const tok = parseCookies(req.headers.cookie)[COOKIE];
    const p = verifyToken(tok);
    return p ? q.userById.get(p.uid) || null : null;
  }
  const isSecure = (req) => req.socket.encrypted || req.headers["x-forwarded-proto"] === "https";
  function setSession(req, res, uid) {
    const tok = signToken({ uid, exp: Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400 });
    res.setHeader(
      "Set-Cookie",
      `${COOKIE}=${tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${isSecure(req) ? "; Secure" : ""}`
    );
  }
  function clearSession(res) {
    res.setHeader("Set-Cookie", `${COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
  }

  /* ---- تحديد المعدل (حماية من التخمين والإزعاج) ---- */
  const hits = new Map();
  const cleaner = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
  }, 60000);
  cleaner.unref();
  function clientIp(req) {
    if (trustProxy) {
      const x = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
      if (x) return x;
    }
    return req.socket.remoteAddress || "unknown";
  }
  function limit(req, bucket, max, windowMs) {
    if (!limitsOn) return;
    const key = `${bucket}:${clientIp(req)}`;
    const now = Date.now();
    let e = hits.get(key);
    if (!e || e.reset < now) e = { count: 0, reset: now + windowMs };
    e.count++;
    hits.set(key, e);
    if (e.count > max) throw new HttpError(429, "محاولات كثيرة، حاول لاحقاً");
  }

  /* ---- مساعدات الطلب والرد ---- */
  function send(res, status, data) {
    const body = JSON.stringify(data);
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    });
    res.end(body);
  }
  function readJson(req, maxBytes = 20000) {
    return new Promise((resolve, reject) => {
      if (!/^application\/json/i.test(req.headers["content-type"] || "")) {
        return reject(new HttpError(415, "نوع المحتوى غير مدعوم"));
      }
      const chunks = [];
      let size = 0;
      req.on("data", (c) => {
        size += c.length;
        if (size > maxBytes) {
          reject(new HttpError(413, "الطلب كبير جداً"));
          req.destroy();
        } else chunks.push(c);
      });
      req.on("end", () => {
        try {
          const v = JSON.parse(Buffer.concat(chunks).toString() || "{}");
          if (v === null || typeof v !== "object" || Array.isArray(v)) throw 0;
          resolve(v);
        } catch {
          reject(new HttpError(400, "صيغة الطلب غير صحيحة"));
        }
      });
      req.on("error", reject);
    });
  }
  const requireUser = (req) => {
    const u = currentUser(req);
    if (!u) throw new HttpError(401, "يجب تسجيل الدخول أولاً");
    return u;
  };
  const requireAdmin = (req) => {
    const u = requireUser(req);
    if (u.role !== "admin") throw new HttpError(403, "هذه الصفحة للمشرفين فقط");
    return u;
  };
  const publicUser = (u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    countryCode: u.country_code,
    phone: u.phone,
    role: u.role,
  });

  /* ============================ المسارات ============================ */
  const routes = [];
  const route = (method, re, fn) => routes.push([method, re, fn]);

  route("GET", /^\/api\/health$/, (req, res) => send(res, 200, { ok: true }));

  route("GET", /^\/api\/config$/, (req, res) =>
    send(res, 200, { contactEmail, contactPhone })
  );

  route("POST", /^\/api\/register$/, async (req, res) => {
    limit(req, "auth", 10, 15 * 60 * 1000);
    const b = await readJson(req);
    const name = str(b.name, 2, 80, "الاسم");
    const email = validEmail(b.email);
    const password = str(b.password, 8, 128, "كلمة المرور");
    const { country_code, phone } = validPhone(b.countryCode, b.phone);
    if (q.userByEmail.get(email)) throw new HttpError(409, "هذا الإيميل مسجل مسبقاً");

    const isFirst = q.userCount.get().n === 0;
    const role = isFirst || (adminEmail && email === adminEmail) ? "admin" : "student";
    const hash = await hashPassword(password);
    let id;
    try {
      id = Number(q.insertUser.run(name, email, country_code, phone, hash, role).lastInsertRowid);
    } catch (e) {
      if (/UNIQUE/i.test(e.message)) throw new HttpError(409, "هذا الإيميل مسجل مسبقاً");
      throw e;
    }
    setSession(req, res, id);
    send(res, 201, { user: publicUser(q.userById.get(id)) });
  });

  route("POST", /^\/api\/login$/, async (req, res) => {
    limit(req, "auth", 10, 15 * 60 * 1000);
    const b = await readJson(req);
    const email = typeof b.email === "string" ? b.email.trim().toLowerCase() : "";
    const password = typeof b.password === "string" ? b.password : "";
    const u = q.userByEmail.get(email);
    // نفّذ الحساب دائماً حتى لا يُعرف إن كان الإيميل موجوداً من زمن الاستجابة
    const ok = await checkPassword(password, u ? u.password_hash : "scrypt$00$00");
    if (!u || !ok) throw new HttpError(401, "الإيميل أو كلمة المرور غير صحيحة");
    setSession(req, res, u.id);
    send(res, 200, { user: publicUser(u) });
  });

  route("POST", /^\/api\/logout$/, (req, res) => {
    clearSession(res);
    send(res, 200, { ok: true });
  });

  route("GET", /^\/api\/me$/, (req, res) => {
    const u = currentUser(req);
    send(res, 200, { user: u ? publicUser(u) : null });
  });

  route("GET", /^\/api\/articles$/, (req, res, url) => {
    const search = (url.searchParams.get("q") || "").trim().slice(0, 80);
    const category = (url.searchParams.get("category") || "").trim().slice(0, 40);
    const where = [];
    const params = [];
    if (search) {
      const like = `%${search.replace(/[\\%_]/g, "\\$&")}%`;
      where.push("(title LIKE ? ESCAPE '\\' OR summary LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')");
      params.push(like, like, like);
    }
    if (category) {
      where.push("category = ?");
      params.push(category);
    }
    const sql =
      "SELECT id,slug,title,category,summary,author,created_at FROM articles" +
      (where.length ? " WHERE " + where.join(" AND ") : "") +
      " ORDER BY id DESC LIMIT 100";
    send(res, 200, {
      articles: db.prepare(sql).all(...params),
      categories: q.categories.all().map((r) => r.category),
    });
  });

  route("GET", /^\/api\/articles\/([^/]+)$/, (req, res, url, m) => {
    let slug;
    try {
      slug = decodeURIComponent(m[1]);
    } catch {
      throw new HttpError(400, "رابط غير صحيح");
    }
    const a = q.articleBySlug.get(slug);
    if (!a) throw new HttpError(404, "المقال غير موجود");
    send(res, 200, { article: a });
  });

  route("POST", /^\/api\/articles$/, async (req, res) => {
    const admin = requireAdmin(req);
    const b = await readJson(req, 100000);
    const title = str(b.title, 3, 150, "العنوان");
    const category = typeof b.category === "string" && b.category.trim() ? str(b.category, 2, 40, "التصنيف") : "عام";
    const summary = str(b.summary, 10, 300, "الملخص");
    const body = str(b.body, 20, 20000, "نص المقال");
    let slug = slugify(title);
    if (q.articleBySlug.get(slug)) slug += "-" + crypto.randomBytes(3).toString("hex");
    const id = Number(q.insertArticle.run(slug, title, category, summary, body, admin.name).lastInsertRowid);
    send(res, 201, { article: { id, slug, title, category, summary, author: admin.name } });
  });

  route("DELETE", /^\/api\/articles\/(\d+)$/, (req, res, url, m) => {
    requireAdmin(req);
    const r = q.deleteArticle.run(Number(m[1]));
    if (!r.changes) throw new HttpError(404, "المقال غير موجود");
    send(res, 200, { ok: true });
  });

  route("POST", /^\/api\/contact$/, async (req, res) => {
    limit(req, "contact", 5, 60 * 60 * 1000);
    const b = await readJson(req);
    const name = str(b.name, 2, 80, "الاسم");
    const email = validEmail(b.email);
    const message = str(b.message, 5, 2000, "الرسالة");
    const { country_code, phone } = validPhone(b.countryCode, b.phone);
    q.insertMessage.run(name, email, country_code, phone, message);
    send(res, 201, { ok: true });
  });

  route("GET", /^\/api\/messages$/, (req, res) => {
    requireAdmin(req);
    send(res, 200, { messages: q.messages.all() });
  });

  route("GET", /^\/api\/users$/, (req, res) => {
    requireAdmin(req);
    send(res, 200, { users: q.users.all() });
  });

  /* ============================ الملفات الثابتة ============================ */
  function serveStatic(req, res, pathname) {
    let rel;
    try {
      rel = decodeURIComponent(pathname);
    } catch {
      return notFound(res);
    }
    if (rel.includes("\0") || rel.split("/").some((s) => s.startsWith("."))) return notFound(res);
    let file = path.join(publicDir, rel);
    if (file !== publicDir && !file.startsWith(publicDir + path.sep)) return notFound(res);
    try {
      if (fs.statSync(file).isDirectory()) file = path.join(file, "index.html");
      const data = fs.readFileSync(file);
      const ext = path.extname(file).toLowerCase();
      res.writeHead(200, {
        "Content-Type": MIME[ext] || "application/octet-stream",
        "Cache-Control": [".svg", ".png", ".jpg", ".ico"].includes(ext) ? "public, max-age=86400" : "no-cache",
      });
      res.end(req.method === "HEAD" ? undefined : data);
    } catch {
      notFound(res);
    }
  }
  function notFound(res) {
    res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
    res.end(
      '<!DOCTYPE html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>404</title>' +
        '<body style="font-family:sans-serif;text-align:center;padding:60px">' +
        '<h1>الصفحة غير موجودة</h1><p><a href="/">العودة إلى الرئيسية</a></p></body></html>'
    );
  }

  /* ============================ المعالج الرئيسي ============================ */
  const server = http.createServer(async (req, res) => {
    // رؤوس الأمان
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; " +
        "frame-src https://www.youtube-nocookie.com; object-src 'none'; base-uri 'self'; " +
        "form-action 'self'; frame-ancestors 'self'"
    );
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    if (isSecure(req)) res.setHeader("Strict-Transport-Security", "max-age=15552000");

    try {
      const url = new URL(req.url, "http://localhost");
      const { pathname } = url;

      if (pathname.startsWith("/api/")) {
        // حماية CSRF: الطلبات المغيِّرة يجب أن تأتي من نفس الموقع
        if (!["GET", "HEAD"].includes(req.method)) {
          const origin = req.headers.origin;
          if (origin) {
            let host = "";
            try {
              host = new URL(origin).host;
            } catch {}
            if (host !== req.headers.host) throw new HttpError(403, "طلب مرفوض");
          }
        }
        for (const [method, re, fn] of routes) {
          if (req.method !== method) continue;
          const m = re.exec(pathname);
          if (m) return await fn(req, res, url, m);
        }
        throw new HttpError(404, "المسار غير موجود");
      }

      if (req.method !== "GET" && req.method !== "HEAD") throw new HttpError(405, "الطريقة غير مسموحة");
      serveStatic(req, res, pathname);
    } catch (e) {
      if (res.headersSent) return res.end();
      if (e instanceof HttpError) return send(res, e.status, { error: e.message });
      console.error(e);
      send(res, 500, { error: "حدث خطأ في السيرفر" });
    }
  });

  server.on("close", () => {
    clearInterval(cleaner);
    try {
      db.close();
    } catch {}
  });

  return { server, db };
}

module.exports = { createApp };

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  const { server } = createApp();
  server.listen(port, "0.0.0.0", () => console.log(`منارة تعمل على http://localhost:${port}`));
  for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => server.close(() => process.exit(0)));
}
